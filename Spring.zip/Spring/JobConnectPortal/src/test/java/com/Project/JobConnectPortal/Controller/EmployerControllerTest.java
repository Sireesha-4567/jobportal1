package com.Project.JobConnectPortal.Controller;

import com.Project.JobConnectPortal.Model.JobPostings;
import com.Project.JobConnectPortal.Service.EmployerService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class EmployerControllerTest {

    @Mock
    private EmployerService employerService;

    @InjectMocks
    private EmployerController employerController;

    public EmployerControllerTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllJobs() {
        JobPostings job = new JobPostings();
        when(employerService.getAllJobs()).thenReturn(Collections.singletonList(job));

        List<JobPostings> jobs = employerController.getAllJobs();
        assertThat(jobs).hasSize(1);
        verify(employerService, times(1)).getAllJobs();
    }

    @Test
    public void testAddJob() {
        JobPostings job = new JobPostings();
        when(employerService.addJob(job)).thenReturn("Job added successfully!");

        ResponseEntity<Map<String, String>> response = employerController.addJob(job);
        assertThat(response.getBody().get("message")).isEqualTo("Job added successfully!");
        verify(employerService, times(1)).addJob(job);
    }
} 