package com.Project.JobConnectPortal.Controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.Project.JobConnectPortal.Model.LoginRequest;
import com.Project.JobConnectPortal.Model.Users;
import com.Project.JobConnectPortal.Service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    private ObjectMapper objectMapper;

    private Users sampleUser;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        sampleUser = new Users("testUser", "test@example.com", "password123", "jobseeker");
    }

    @Test
    void testRegisterUserSuccess() throws Exception {
        doNothing().when(userService).registerUser(any(Users.class));

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sampleUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Registration successful"));
    }

    @Test
    void testRegisterUserFailure() throws Exception {
        doThrow(new RuntimeException("Email already exists")).when(userService).registerUser(any(Users.class));

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sampleUser)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Error: Email already exists"));
    }

    @Test
    void testLoginSuccess() throws Exception {
        // Properly construct the login request with actual values
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("test@example.com");
        loginRequest.setPassword("password123");
        loginRequest.setType("jobseeker");

        // Mock the service call with the correct values
        when(userService.login("test@example.com", "password123", "jobseeker"))
            .thenReturn("Login successful");

        // Perform the POST request and validate response
        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Login successful"));
    }


    @Test
    void testLoginFailure() throws Exception {
        // Properly construct a LoginRequest with incorrect password
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("test@example.com");
        loginRequest.setPassword("wrongpass");
        loginRequest.setType("jobseeker");

        // Mock service response when invalid credentials are used
        when(userService.login("test@example.com", "wrongpass", "jobseeker"))
                .thenReturn("Invalid credentials");

        // Perform POST request and check response message
        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Invalid credentials"));
    }

}
