package com.Project.JobConnectPortal.Repository;

import com.Project.JobConnectPortal.Model.JobPostings;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class JobPostingsRepoTest {

    @Autowired
    private JobPostingsRepo jobPostingsRepo;

    @Test
    public void testSaveAndFindById() {
        JobPostings job = new JobPostings();
        job.setJobName("Java Developer");
        job.setDepartment("IT");
        job.setSkills("Java, Spring");
        job.setExperience(2);
        job.setJobDescription("Backend Developer");
        job.setSalary(50000);
        job.setEmployerId(1);
        job.setCompanyName("TestCompany");
        job.setStatus("pending");

        JobPostings saved = jobPostingsRepo.save(job);
        JobPostings found = jobPostingsRepo.findById(saved.getJobId());

        assertThat(found).isNotNull();
        assertThat(found.getJobName()).isEqualTo("Java Developer");
    }

    @Test
    public void testFindByCompanyname() {
        JobPostings job = new JobPostings();
        job.setCompanyName("TestCompany");
        jobPostingsRepo.save(job);

        List<JobPostings> jobs = jobPostingsRepo.findByCompanyname("TestCompany");
        assertThat(jobs).isNotEmpty();
    }
} 