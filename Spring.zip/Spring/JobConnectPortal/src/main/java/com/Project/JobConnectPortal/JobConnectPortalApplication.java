package com.Project.JobConnectPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobConnectPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobConnectPortalApplication.class, args);
	}

}
