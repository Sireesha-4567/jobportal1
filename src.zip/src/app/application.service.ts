// import { Injectable } from '@angular/core';
// import { Application } from './application';
// import { Observable, tap } from 'rxjs';
// import { InterviewServiceService } from './interview-service.service';
// import { HttpClient } from '@angular/common/http';
// import { Interview } from './interview';


// @Injectable({
//   providedIn: 'root'
// })
import { Injectable } from '@angular/core';
import { Application } from './application';
import { InterviewServiceService } from './interview-service.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {
  private applications: Application[] = [];
 
  constructor(private interviewService: InterviewServiceService,private http:HttpClient) {}
  strUrl = "http://localhost:8091/";
  getAllApplications(): Observable<Application[]> {
    const strGetUrl = this.strUrl + "api/employer/applications";
    return this.http.get<Application[]>(strGetUrl).pipe(
      tap(applications => this.applications = applications) // Update the service's `applications` array
    );
  }
  filteredApplications( qualifications: string, experience: string): Application[] {
    return this.applications.filter((app) => {
      // Filter by seekerId if it's provided
     
      // Filter by qualifications (case-insensitive check)
      const matchesQualifications = qualifications ? app.qualification.toLowerCase().includes(qualifications.toLowerCase()) : true;
 
      // Filter by experience (greater than or equal to the input experience)
      const matchesExperience = experience ? app.experience = experience : true;
 
      // Only include applications that match all conditions
      return  matchesQualifications && matchesExperience;
    });
  }
 
 
  updateApplicationStatus(applicationId: number, status: string): void {
    const application = this.applications.find(app => app.applicationId === applicationId);
   
    if (application) {
      application.status = status;
 
      // If the application is approved, schedule an interview
      if (status === 'Approved') {
        const interview = {
          interview_Id: this.interviewService.getInterviews().length + 1, // Use correct interview_Id
          applicationId: application.applicationId, // Correctly map application_id
          userId: application.userId, // Pass the userId from the application
          name: application.name,  // Assuming `name` is part of the Application model
          interview_date: new Date(),  // Set the current date as interview date
          interview_status: 'Scheduled', // Set status to "Scheduled"
          feedback: '' // Feedback starts empty
        };
 
        // Schedule the interview by calling the InterviewService
        this.interviewService.scheduleInterview(interview);
      }
    }
  }
}
