import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone:false
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  passwordMismatch: boolean = false;
togg: any;

  constructor(private fb: FormBuilder, private userService: JobSearchService, private router: Router) {
    this.registerForm = this.fb.group({
      userName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      type: ['', Validators.required]  // Add the 'type' field with validation
    });

   

    // Watch for changes in the password and confirm password fields
    this.registerForm.valueChanges.subscribe(() => {
      this.checkPasswordMatch();
    });
  }

  ngOnInit(): void {}

  // Check if password and confirm password match
  checkPasswordMatch() {
    const password = this.registerForm.get('password')?.value;
    const confirmPassword = this.registerForm.get('confirmPassword')?.value;
    this.passwordMismatch = password !== confirmPassword;
  }

  // Submit registration
 onRegisterSubmit(): void {
    // Original code - commented out
    // console.log('Response:');
    // if ( !this.passwordMismatch) {
    //   console.log('Submitting:', this.registerForm.value);
    //   this.userService.register(this.registerForm.value).subscribe(
    //     (response: any) => {
    //       console.log('Response:', response);
    //       alert(response.message || 'Registration Successful');
    //       setTimeout(() => this.router.navigate(['/login']), 500);
    //     },
    //     error => {
    //       console.error('Registration Error:', error);
    //       alert('Registration failed');
    //     }
    //   );
    // }
    
    // Fixed code - proper validation and response handling
    if (this.registerForm.valid && !this.passwordMismatch) {
      // Create user object without confirmPassword
      const userData = {
        userName: this.registerForm.get('userName')?.value,
        email: this.registerForm.get('email')?.value,
        password: this.registerForm.get('password')?.value,
        type: this.registerForm.get('type')?.value
      };
      
      console.log('Submitting:', userData);
      this.userService.register(userData).subscribe(
      (response: any) => {
        console.log('Response:', response);
        alert(response.message || 'Registration Successful');
        setTimeout(() => this.router.navigate(['/login']), 500);
      },
      error => {
        console.error('Registration Error:', error);
          if (error.error && error.error.message) {
            alert('Registration failed: ' + error.error.message);
          } else {
            alert('Registration failed. Please try again.');
      }
        }
      );
    } else {
      alert('Please fill all required fields and ensure passwords match.');
  }
}
}
