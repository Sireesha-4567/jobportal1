import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JobSearchComponent } from './job-search/job-search.component';
import { JobSearchService } from './job-search.service';
import { HttpClientModule } from '@angular/common/http';
import { JobsComponent } from './jobs/jobs.component';
import { InsightsComponent } from './insights/insights.component';
import { TrendsComponent } from './trends/trends.component';
import { InsightsTrendsComponent } from './insights-trends/insights-trends.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { EmployerjobsComponent } from './employerjobs/employerjobs.component';
import { DatePipe } from '@angular/common';
import { AdminComponent } from './admin/admin.component';
import { EmployerComponent } from './employer/employer.component'; // Import DatePipe

@NgModule({
  declarations: [
    AppComponent,
    JobSearchComponent,
    JobsComponent,
    InsightsTrendsComponent,
    InsightsComponent,
    TrendsComponent,
    LoginComponent,
    RegisterComponent,
    EmployerjobsComponent,
    AdminComponent,
    EmployerComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [JobSearchService, DatePipe],  // Add DatePipe here
  bootstrap: [AppComponent]
})
export class AppModule { }
