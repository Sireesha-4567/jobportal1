

export class Application {
  applicationId!: number;
  jobId!: number;
  jobRole!:string;
  companyName!:string;
  employerId!:number;
  userId!:number;
  name!:string;
  qualification!:string;
  resumeUrl!:string;
  mobile!:number;
  email!:string;
  experience!:string;
  appliedAt!:string;
  status!:string;
}
