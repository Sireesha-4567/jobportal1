import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { JobSearchService } from '../job-search.service';
import { job } from '../jobs';

@Component({
  selector: 'app-employerjobs',
  standalone: false,
  templateUrl: './employerjobs.component.html',
  styleUrls: ['./employerjobs.component.css']
})
export class EmployerjobsComponent implements OnInit {
  JobForm!: FormGroup;
  bAdd = false;
  strAddNames = '';
  jobLst: any;
  showTable = false;
  bSearch = true;
  editingJobId: number | null = null; // Track which job is being edited

  constructor(private jobService: JobSearchService, private fb: FormBuilder) {
    this.JobForm = this.fb.group({
      // jobId: [''],
      job_name: [''],
      department: [''],
      skills: [''],
      experience: [''],
      job_description: [''],
      salary: [''],
      employer_id: [''],
      // postDate: [''],
      company_name: ['']
    });
  }

  ngOnInit(): void {
    this.getAllJobsList();
  }


  addJobList() {
    this.bAdd = true;
    this.strAddNames = "Add Record";
    this.JobForm.reset(); 
  }

  // Function to handle Add Job Record
  AddJobRecord() {
    const jobObj: any = {
      jobId: this.strAddNames === "Edit Record" ? this.editingJobId : undefined,
      job_name: this.JobForm.get('job_name')?.value,
      department: this.JobForm.get('department')?.value,
      skills: this.JobForm.get('skills')?.value,
      experience: this.JobForm.get('experience')?.value,
      job_description: this.JobForm.get('job_description')?.value,
      salary: this.JobForm.get('salary')?.value,
      employer_id: this.JobForm.get('employer_id')?.value,
      company_name: this.JobForm.get('company_name')?.value
    };

    if (this.strAddNames == "Add Record") {
      this.jobService.insertJob(jobObj).subscribe({
        next: (data) => {
          alert('Record inserted successfully');
          this.getAllJobsList();
          this.JobForm.reset();
          console.log(JSON.stringify(data));
        },
        error: (err) => console.log("Error while inserting record: " + JSON.stringify(err)),
        complete: () => console.log('Insert operation is successful')
      });
    } else if (this.strAddNames == "Edit Record" && this.editingJobId) {
      this.jobService.updateJob(this.editingJobId, jobObj).subscribe({
        next: (data) => {
          alert('Record updated successfully');
          this.getAllJobsList();
          this.editingJobId = null;
          this.strAddNames = "Add Record";
          this.JobForm.reset();
          console.log(JSON.stringify(data));
        },
        error: (err) => console.log("Error while updating record: " + JSON.stringify(err)),
        complete: () => console.log('Update operation is successful')
      });
    }
  }

  // Function to toggle search form visibility
  searchForm() {
    this.bSearch = !this.bSearch;
  }

  // Function to fetch all jobs
  getAllJobsList() {
    this.jobService.getAllJobs().subscribe({
      next: (data) => {
        this.jobLst = data;
        this.showTable = true;
      },
      error: (err) => console.log("Unable to fetch from server: " + err),
      complete: () => console.log("Fetching data from server is complete")
    });
  }


  EditJobRecord(jobRecord: any): void {
    console.log('EMPLOYERJOBS EditJobRecord called with:', jobRecord);
    this.bAdd = true;
    console.log('EMPLOYERJOBS bAdd set to', this.bAdd);
    this.strAddNames = "Edit Record";
    this.editingJobId = jobRecord.jobId;
    this.JobForm.patchValue({
      job_name: jobRecord.job_name || jobRecord.jobName || jobRecord.jobname || '',
      department: jobRecord.department || '',
      skills: jobRecord.skills || '',
      experience: jobRecord.experience || '',
      job_description: jobRecord.job_description || jobRecord.jobDescription || '',
      salary: jobRecord.salary || '',
      employer_id: jobRecord.employer_id || jobRecord.employerId || '',
      company_name: jobRecord.company_name || jobRecord.companyName || jobRecord.companyname || ''
    });
    console.log('EMPLOYERJOBS Form values after patch:', this.JobForm.value);
  }

  // Function to delete a job record
  deleteJobRecord(jobId: number) {
    this.jobService.deleteJobRecord(jobId).subscribe({
      next: (data: any) => {
        alert("Record deleted successfully");
        this.getAllJobsList();
        console.log(JSON.stringify(data));
      },
      error: (err: any) => {
        alert(JSON.stringify(err));
      },
      complete: () => console.log('Delete operation is complete')
    });
  }
}
