export class Job{
    jobId?: number;
    job_name!:String;
    company_name!:String;
    department!:String;
    skills!:String;
    experience!:String;
    job_description!:String;
    salary!: number;
    emp_id!: number;
    // post_date!: String;
    constructor(job_name:String,company_name:String,department:String,
        skills:String,experience:String,job_description:String,salary: number, emp_id: number, jobId?: number)
        {
        this.jobId = jobId;
        this.job_name=job_name;
        this.company_name=company_name;
        this.department=department;
        this.skills=skills;
        this.experience=experience;
        this.job_description=job_description;
        this.salary=salary;
        this.emp_id=emp_id;
        // this.post_date=post_date;
    }
 
}