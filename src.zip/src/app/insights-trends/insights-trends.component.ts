import { Component, OnInit } from '@angular/core';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-insights-trends',
  standalone: false,
  templateUrl: './insights-trends.component.html',
  styleUrl: './insights-trends.component.css'
})
export class InsightsTrendsComponent implements OnInit {

  jobInsights: any[] = [];
  jobTrends: any[] = [];

  constructor(
    private jobSearchService: JobSearchService
  ) { }

  ngOnInit(): void {
    // Initially, no data; data will be fetched when the button is pressed.
  }

  // Fetch Job Insights when button is clicked
  fetchJobInsights(): void {
    this.jobSearchService.getJobInsights().subscribe((data: any[]) => {  
      this.jobInsights = data;
      console.log('Job Insights:', this.jobInsights);
    });
  }

  // Fetch Job Trends when button is clicked
  fetchJobTrends(): void {
    this.jobSearchService.getJobTrends().subscribe((data: any[]) => {  
      this.jobTrends = data;
      console.log('Job Trends:', this.jobTrends);
    });
  }
}
